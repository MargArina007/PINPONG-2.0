from pygame import*

w = 700
h = 500

ball = image.load("ball.jpg")
ball = transform.scale(ball, (50,50))

win = display.set_mode((w,h))
win.fill( (0,225,0) )

game_mode = "игра"
while True:

    if game_mode == "игра":
        win.blit(ball, (200,200))

    for e in event.get():

        if e.type == QUIT:
            exit()

    display.update()
